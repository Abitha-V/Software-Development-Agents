# Architecture Deep-Dive

## Supervisor Pattern

This system implements the **Supervisor + Workers** multi-agent pattern, a well-established architecture for tasks that require dynamic routing across specialised agents.

### Why not a fixed pipeline?

A fixed pipeline (Engineer → Reviewer → Done) assumes every task needs exactly one coding pass and one review. In practice:

- Simple tasks (fix a bug, add a function) need only the Engineer
- Complex tasks (build a full module) need multiple Engineer → Reviewer cycles
- The Supervisor decides this dynamically based on the conversation state

### Routing Mechanism

The Supervisor emits structured JSON on every turn:

```json
{
  "next": "SOFTWARE ENGINEER",
  "Instruction": "Implement the user authentication endpoint with JWT token generation and password hashing using bcrypt."
}
```

The `next` field is written to **flow state** and read by the **Condition node**, which branches to the correct agent. This keeps routing logic out of prose and makes it deterministic.

---

## Memory Strategy

All three agents (Supervisor, Engineer, Reviewer) use **allMessages** memory — the full conversation history is passed on every turn.

This is intentional:

- The Engineer sees what the Reviewer flagged in the previous iteration and can fix it without being re-told
- The Reviewer sees what the Engineer claimed to have fixed and can verify it
- The Supervisor reads the full dialogue to make an informed routing decision

Trade-off: this grows the context window with each loop. For very long sessions (5+ loops), consider switching the Supervisor to `conversationSummaryBuffer` to compress older turns while keeping recent ones verbatim.

---

## Loop Control

Each agent feeds into a **Loop node** (max 5 iterations) that points back to the Supervisor. The loop count is per-agent, not global — so in theory the system could run up to 10 total agent turns (5 Engineer + 5 Reviewer) before hitting a fallback.

The **FINISH** condition is the clean exit — when the Supervisor decides the task is complete, it routes to the **Generate Final Answer** node instead of looping, which synthesises the full output from the conversation history.

---

## Flow State

| Key | Set by | Read by | Purpose |
|-----|--------|---------|---------|
| `next` | Supervisor (via llmUpdateState) | Condition node | Which agent to invoke next |
| `instructions` | Supervisor (via llmUpdateState) | Software Engineer, Code Reviewer (via llmUserMessage) | Specific subtask for this iteration |

State is session-scoped and persists across loops within a single conversation.
